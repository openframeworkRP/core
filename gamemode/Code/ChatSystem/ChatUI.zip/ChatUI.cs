﻿using SmallLife.Command;
using SmallLife.Extension;
using System.Text.RegularExpressions;
using static Facepunch.NotificationSystem;
using SmallLife.Models;
using static SmallLife.Models.RealityPanel;
using Facepunch;
using SmallLife.Systems.Jobs;

namespace SmallLife.ChatSystem;

/// <summary>
/// Abstract base class for a chat system in the game.
/// This class provides basic functionalities and can be extended for custom behaviors.
/// </summary>
[StyleSheet]
public partial class ChatUI : RealityPanel, RealityPanel.ITriggeable
{
	public static ChatUI Instance { get; private set; }

	/// <summary>
	/// Gets the list of muted clients.
	/// </summary>
	public IList<Connection> MutedClients { get; private set; } = new List<Connection>();

	/// <summary>
	/// Gets or sets the list of chat messages.
	/// </summary>
	public IList<ChatMessage> Messages { get; set; } = new List<ChatMessage>();

	/// <summary>
	/// Gets or sets the messages canvas panel.
	/// </summary>
	public Panel MessagesCanvas { get; protected set; }

	/// <summary>
	/// Gets the loaded emoji list.
	/// </summary>
	public IEnumerable<ChatEmoji> EmojiList { get; protected set; }

    public string InputAction => "Chat";

    /// <summary>
    /// Initializes a new instance of the <see cref="ChatUI" /> class.
    /// </summary>
    public ChatUI()
	{
		
		Instance = this;
		EmojiList = FileSystem.Mounted.ReadJson( "ui/chatemoji.json", new List<ChatEmoji>() );
		
		//Server.AddLog( $"BaseChat: new instance.", Logs.LogType.UI, Logs.LogLevel.Debug );
	}

	/// <summary>Sends a message.</summary>
	/// <param name="message">The message to send.</param>
	public void Send( ChatMessage message )
	{
		if ( message.IsCommand )
		{
			var caller = Client.Local;

			Log.Info( "[BaseChat] RPC_FromChatMessage: " + caller.DisplayName );

			string[] tokens = message.Message.Remove( 0, 1 ).Split( ' ', StringSplitOptions.RemoveEmptyEntries );
			if ( tokens.Length == 0 ) return;

			string commandName = tokens[0];
			var context = CommandCallback.Find( commandName );

			if ( context == null )
			{
				caller.Notify( NotificationType.Error, $"<font color='#FF5555'>Unknown command:</font> <font color='#FFAAAA'>{commandName}</font>" );
				return;
			}

			/*if ( !context.DTO.Enabled )
			{
				caller.Notify( NotificationType.Error, $"Command <font color='#37FA74'>'{commandName}'</font> is <font color='#FF5555'>disabled</font>." );
				return;
			}*/

			/*bool HasPermission = Client.Local.Data.HasCommandPermission(context.DTO.Id);
			if(!HasPermission )
			{
				caller.Notify( NotificationType.Error, $"<font color='#FF5555'>Insufficient permissions 😀!</font>" );
				return;
			}*/

			var builder = CommandCallback.Call( commandName );
			var parameters = context.Args;


			for ( int i = 0; i < parameters.Length; i++ )
			{
				var param = parameters[i];

				if ( i + 1 < tokens.Length )
				{
					builder.Set( param.Name, tokens[i + 1] );
				}
				else if ( !param.IsOptional )
				{
					caller.Notify( NotificationType.Error, $"<font color='#FF5555'>Missing argument</font> for '<font color='#FFAAAA'>{param.Name}</font>'." );
					return;
				}
			}

			try
			{
				builder.Execute();
				// Optional: send success feedback to user
				//ServerUtility.SayToClient( caller, $"<font color='#37FA74'>Command</font> <font color='#AAAAFF'>'{commandName}'</font> <font color='#37FA74'>executed successfully.</font>" );
			}
			catch ( Exception ex )
			{
				//Log.Error( $"[BaseChat] Error executing command '{commandName}': {ex.Message}" );
				//ServerUtility.SayToClient( caller, $"<font color='#FF5555'>Command failed:</font> <font color='#FFAAAA'>{ex.Message}</font>" );
			}

			return;
		}

		OnMessageSent( message );
		Receive( message );
	}

	/// <summary>Sends a message to a specific target.</summary>
	/// <param name="target">The target connection.</param>
	/// <param name="message">The message to send.</param>
	public void SendTo( Connection target, ChatMessage message )
	{
		OnMessageSent( message );
		using ( Rpc.FilterInclude( (c => c == target) ) )
			Receive( message );
	}

	/// <summary> Clears the chat.</summary>
	public virtual void Clear()
	{
		Messages.Clear();
		MessagesCanvas.DeleteChildren( false );
	}

	/// <summary>Receives a message.</summary>
	/// <param name="message">The message received.</param>
	[Rpc.Broadcast]
	public static void Receive( ChatMessage message )
	{
		if ( Instance == null ) return;

		message.Process();
		Instance.OnMessageReceived( message );
		Instance.Messages.Add( message );

		if ( message.IsCommand )
			return;

		Instance.MessagesCanvas.AddChild( message.CreateUI() );
	}

	/// <summary>Called when a message is received.</summary>
	/// <param name="message">The message received.</param>
	public virtual void OnMessageReceived( ChatMessage message )
	{
	}

	/// <summary>Called when a message is sent.</summary>
	/// <param name="message">The message sent.</param>
	public virtual void OnMessageSent( ChatMessage message )
	{
	}

	/// <summary>Mutes a specific user in the chat.</summary>
	/// <param name="user">The user to mute.</param>
	public virtual void MuteUser( string user )
	{
	}

	/// <summary>Unmutes a specific user in the chat.</summary>
	/// <param name="user">The user to unmute.</param>
	public virtual void UnmuteUser( string user )
	{
	}

	/// <summary>Represents a chat message.</summary>
	public class ChatMessage
	{
		private readonly Dictionary<string, string> predefinedStyles = new Dictionary<string, string>()
		{
			{
				"important",
				"font-weight:bold;color:red;"
			},
			{
				"notice",
				"font-style:italic;color:blue;"
			},
			{
				"mayor",
				"font-weight:bold;font-family:Lugrasimo;color:yellow;font-size:18px;"
			}
		};

		/// <summary>Gets or sets the network ID of the author of the message.</summary>
		public Guid AuthorId { get; set; }

		/// <summary>Gets the author steamid for avatar purpose.</summary>
		public ulong? AuthorSteamId { get; set; }

		/// <summary>We store the author name in this variable in order to have a tracking about him in the chat even if he disconnect.</summary>
		public string AuthorName { get; set; }

		/// <summary>Gets or sets the message content.</summary>
		public string Message { get; set; }

		/// <summary>Gets or sets a value indicating whether the message is private.</summary>
		public bool Private { get; set; }

		/// <summary>True if this message has been processed (formatted with colors, etc..) </summary>
		public bool Processed { get; set; }

		public bool HostMessage { get; set; }
		
		/// <summary>
		/// Background image of the chat entry.
		/// </summary>
		public string Background { get; set; }

		/// <summary>True if this message was intended to be a command.</summary>
		public bool IsCommand => Message.StartsWith( '!' ) || Message.StartsWith( '/' );

		public DateTime Date { get; set; } = DateTime.Now;

		/// <summary>Parses the message and applies custom styles based on tags.</summary>
		public void ParseMessage()
		{
			if(!IsCommand)
			{
				// Replace custom <font> tags with styled spans for regular messages
				string processedMessage = Regex.Replace( Message, @"<font(.*?)>(.*?)<\/font>", match =>
				{
					string attributes = match.Groups[1].Value;
					string content = match.Groups[2].Value;

					string style = "";

					// Extract and process attributes
					if ( attributes.Contains( "color" ) )
					{
						string color = Regex.Match( attributes, @"color\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						style += $"color:{color};";
					}
					if ( attributes.Contains( "bold" ) )
					{
						style += "font-weight:bold;";
					}
					if ( attributes.Contains( "italic" ) )
					{
						style += "font-style:italic;";
					}
					if ( attributes.Contains( "underline" ) )
					{
						style += "text-decoration:underline;";
					}
					if ( attributes.Contains( "strikethrough" ) )
					{
						style += "text-decoration:line-through;";
					}
					if ( attributes.Contains( "size" ) )
					{
						string size = Regex.Match( attributes, @"size\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						style += $"font-size:{size};";
					}
					if ( attributes.Contains( "family" ) )
					{
						string family = Regex.Match( attributes, @"family\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						style += $"font-family:{family};";
					}
					if ( attributes.Contains( "bgcolor" ) )
					{
						string bgcolor = Regex.Match( attributes, @"bgcolor\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						style += $"background-color:{bgcolor};";
					}
					if ( attributes.Contains( "align" ) )
					{
						string align = Regex.Match( attributes, @"align\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						style += $"text-align:{align};";
					}
					if ( attributes.Contains( "link" ) )
					{
						string link = Regex.Match( attributes, @"link\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						content = $"<a href='{link}'>{content}</a>";
					}
					if ( attributes.Contains( "animation" ) )
					{
						string animation = Regex.Match( attributes, @"animation\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						style += $"animation:{animation};";
					}
					if ( attributes.Contains( "style" ) )
					{
						string styleName = Regex.Match( attributes, @"style\s*=\s*[""'](.*?)[""']" ).Groups[1].Value;
						if ( predefinedStyles.TryGetValue( styleName, out var predefinedStyle ) )
						{
							style += predefinedStyle;
						}
					}

					Processed = true;

					// Construct the styled message content
					return $"<label class='message customised' style='{style}'>{content}</label>";
				} );

				Message = processedMessage;
			}
		}

		public void Process()
		{
			var owner = FindOwner();
			if( HostMessage ) 
				AuthorName = "HOST";
			else
			{
				/*if ( string.IsNullOrEmpty( owner.GetClient().Data.Character.FirstName ) )
					AuthorName = owner?.DisplayName;
				else
					AuthorName = owner.GetClient().Data.Character.FirstName;*/

				AuthorName = owner?.DisplayName;
			}

			//AuthorSteamId = (ulong)(owner?.SteamId ?? null);
		}

		/// <summary>Creates the UI for the chat message.</summary>
		/// <returns>A <see cref="Panel" /> representing the chat message UI.</returns>
		public Panel CreateUI()
		{
			ParseMessage();
			return new ChatEntry( this );
		}

		/// <summary>Finds the owner of the message.</summary>
		/// <returns>The <see cref="Connection" /> representing the owner.</returns>
		public Connection FindOwner() => Connection.Find( AuthorId );
	}

	/// <summary>Represents a chat emoji</summary>
	public class ChatEmoji
	{
		public string Emoji { get; set; }

		public string Category { get; set; }

		public string[] Tags { get; set; }
	}

	/// <summary>Represents a chat entry panel.</summary>
	public class ChatEntry : Panel
	{
		/// <summary>Gets or sets the chat message.</summary>
		public ChatMessage Message { get; set; }

		/// <summary>Initializes a new instance of the <see cref="ChatEntry" /> class.</summary>
		/// <param name="_message">The chat message.</param>
		public ChatEntry( ChatMessage _message )
		{
			Message = _message;
			AddClass( "chatentry" );
			SetClass( "fromhost", _message.HostMessage );

			var job = _message.FindOwner()?.GetClient().Data.Job;
			//Style.SetBackgroundImage( $"linear-gradient(to right, rgba({JobSystem.GetJob( job ).Color.Rgb}, 0.05), rgba(0, 0, 0, 0.1))" );

			if( !string.IsNullOrEmpty(_message.Background))
			{
				Panel background = new Panel(this);
				background.Style.SetBackgroundImage( $"url({_message.Background})" );
			}

			ChildContent = builder =>
			{
				//						<img class='avatar' src='avatar:{Message.AuthorSteamId}' />

				if(_message.HostMessage)
				{
					// Normal player message
					builder.AddMarkupContent( 0, $@"
						<div class='background'></div>
						<label class='author'>{_message.AuthorName} 📢</label>
						<span class='message'>{_message.Message}</span>
						<span class='time'>
							{DateTime.Now.ToString( "HH:mm" )}
						</span>
					" );
				}
				else
				{
					// Normal player message
					builder.AddMarkupContent( 0, $@"
						<label class='job'>{JobSystem.GetJob( job ).DisplayName}</label>
						<label class='author'>{_message.AuthorName}</label>
						<span class='message'>{_message.Message}</span>
						<span class='time'>
							{DateTime.Now.ToString( "HH:mm" )}
						</span>
					" );
				}
			};
		}


		protected override async void OnParametersSet()
		{
			await Task.Delay( 5000 );

			SetClass( "faded", true );
			StateHasChanged();
		}
	}

	protected override int BuildHash()
	{
		if ( InputEntry == null ) return 0;

		return HashCode.Combine( IsTriggered, InputEntry.Text );
	}
}
